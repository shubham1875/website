function myFunction() {
    var dots = document.getElementById("stop");
    var moreText = document.getElementById("more");
    var btnText = document.getElementById("btn");
  
    if (dots.style.display === "none") {
      dots.style.display = "inline";
      btnText.innerHTML = "Read more";
      moreText.style.display = "none";
    } else {
      dots.style.display = "none";
      btnText.innerHTML = "Read less";
      moreText.style.display = "inline";
    }
  }
  burger = document.querySelector('.burger')
  navbar = document.querySelector('.navbar')
  navlist = document.querySelector('.nav-list')
  rightNav = document.querySelector('.rightNav')
  burger.addEventListener('click', () => {
      rightNav.classList.toggle('vis');
      nav-list.classList.toggle('vis');
      navbar.classList.toggle('h-nav');
    })