function showTime(){
    var date = new Date();
    var hr = date.getHours(); 
    var min = date.getMinutes(); 
    var sec = date.getSeconds(); 
    var session = "AM";
    
    if(hr == 0){
        hr = 12;
    }
    
    if(hr > 12){
        hr = hr - 12;
        session = "PM";
    }
    
    hr = (hr < 10) ? "0" + hr : hr;
    min = (min < 10) ? "0" + min : min;
    sec = (sec < 10) ? "0" + sec : sec;
    
    var time = hr + ":" + min + ":" + sec + " " + session;
    document.getElementById("display").innerText = time;
    document.getElementById("display").textContent = time;
    
    setTimeout(showTime, 1000);
    
}

showTime();

icon = document.querySelector('.icon')
navbar = document.querySelector('.navbar')
navlist = document.querySelector('.nav-list')
rightNav = document.querySelector('.rightNav')
icon.addEventListener('click', () => {
    rightNav.classList.toggle('vis');
    nav-list.classList.toggle('vis');
    navbar.classList.toggle('h-nav');
  })