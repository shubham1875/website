icon = document.querySelector('.icon')
navbar = document.querySelector('.navbar')
navlist = document.querySelector('.nav-list')
rightNav = document.querySelector('.rightNav')
icon.addEventListener('click', () => {
    rightNav.classList.toggle('vis');
    nav-list.classList.toggle('vis');
    navbar.classList.toggle('h-nav');
  })